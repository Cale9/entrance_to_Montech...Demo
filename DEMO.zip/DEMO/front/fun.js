
      // Array con las rutas de las imágenes
      const images = ['/front/imagenes/TrekDoradajpg.jpg', '/front/imagenes/TrekDH.jpg', '/front/imagenes/SantaCruzDorada.jpg', '/front/imagenes/Orbea.jpg', '/front/imagenes/Scott.jpg'];

      // Índice de la imagen actual
      let currentIndex = 0;

      // Función para cambiar la imagen
      function changeImage() {
          document.getElementById('myImage').src = images[currentIndex];
          currentIndex = (currentIndex + 1) % images.length;
      }

      // Iniciar el slideshow
      setInterval(changeImage, 6000); // Cambia cada 6 segundos
  